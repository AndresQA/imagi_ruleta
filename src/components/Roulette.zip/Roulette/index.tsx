import "./index.scss";

interface ItemRoulette {
    id: string,
    title: string,
    img: string
}

const RouletteGame = ({ items }: { items: ItemRoulette[] }) => {


    return <div className="Roulette">
        <div className="Roulette__container">
            {items.map((item, index) => {
                const { img } = item;

                return <div className="icons" style={{ transform: `translate(-50%, -50%) rotate(${360 / items.length * index}deg)` }}>
                    <img className="icons__img" src={img} alt="" />
                </div>
            })}
        </div>

    </div>
}

export default RouletteGame;